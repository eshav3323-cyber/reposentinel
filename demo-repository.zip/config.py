﻿api_key = "DEMO_EXAMPLE_KEY_12345"
DEBUG = True
